#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <netdb.h>
#include<sys/epoll.h>
#include<errno.h>
#include<fcntl.h>
#include<arpa/inet.h>
#include<signal.h>

/* Recommended max cache and object sizes */
#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400

static const char *user_agent_hdr = "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:97.0) Gecko/20100101 Firefox/97.0";

struct request_info {
	int clientfd;
	int serverfd;
	int state; //0=read_request, 1=send_request, 2=read_response, 3=send_response, 4=done
	char readBuf[MAX_CACHE_SIZE];
	char writeBuf[MAX_CACHE_SIZE];
	int readFromClient;
	int writeToServer;
	int writtenToServer;
	int readFromServer;
	int writtenToClient;
};

struct request_info *newRequest;
struct request_info *activeRequest;
struct epoll_event event;
struct epoll_event *events;

int all_headers_received(char *);
int parse_request(char *, char *, char *, char *, char *, char *);
void test_parser();
void print_bytes(unsigned char *, int);
int open_sfd(int argc, char* argv[]);
void handle_new_clients(int efd, int sfd);
void handle_client(struct request_info *request, int erfd, int ewfd);
void read_request(struct request_info *request, int ewfd);
void send_request(struct request_info *request, int erfd);
void read_response(struct request_info *request, int ewfd);
void send_response(struct request_info *request);

int signalFlag = 0;
void sig_handler(int signum) {
	signalFlag = 1;
}


int main(int argc, char* argv[])
{
	struct sigaction sig;

	sig.sa_flags = SA_RESTART;
	sig.sa_handler = sig_handler;
	sigaction(SIGINT, &sig, NULL);

	int erfd = epoll_create1(0); // epoll file descriptor (read)
	if (erfd < 0) {
		exit(1);
	}

	int ewfd = epoll_create1(0); // epoll file descriptor (write)
	if (ewfd < 0) {
		exit(1);
	}

	int lfd = open_sfd(argc, argv);
	newRequest = malloc(sizeof(struct request_info));
	newRequest->clientfd = lfd;

	event.data.ptr = newRequest;
	event.events = EPOLLIN | EPOLLET;
	if (epoll_ctl(erfd, EPOLL_CTL_ADD, lfd, &event) < 0) {
		exit(1);
	}

	events = calloc(64, sizeof(struct epoll_event));

	while(1) {
		int result = epoll_wait(erfd, events, 64, 1000);

		if(result < 0) {
			if (errno == EBADF) {
				break;
			}
			else if (errno == EFAULT) {
				break;
			}
			else if (errno == EINTR) {
				break;
			}
			else if (errno == EINVAL) {
				break;
			}
		}
		else if (result == 0) {
			if (signalFlag) {
				break;
			}
		}

		for (int i = 0; i < result; ++i) {
			activeRequest = (struct request_info *)(events[i].data.ptr);

			if ((events[i].events & EPOLLERR) || (events[i].events & EPOLLHUP) || (events[i].events & EPOLLRDHUP)) {
				close(activeRequest->clientfd);
				close(activeRequest->serverfd);
				free(activeRequest);
				continue;
			}

			if (activeRequest->clientfd == lfd) {
				handle_new_clients(erfd, lfd);
			}
			else {
				handle_client(activeRequest, erfd, ewfd);
			}
		}
	}
	free(events);
	close(erfd);
	close(ewfd);
	close(lfd);
	return 0;
}

int all_headers_received(char *request) {
	if (strstr(request, "\r\n\r\n") != NULL) {
		return 1;
	}
	return 0;
}

int parse_request(char *request, char *method, char *hostname, char *port, char *path, char *headers) {
	if (!all_headers_received(request)) {
		return 0;
	}

	char* buf;
	int found = 0;
	unsigned int i = 0;
	while (i < strlen(request)) {
		if (request[i] == ' ') {
			found = 1;
			break;
		}
			++i;
	}
	if (found != 1) {
		return 0;
	}
	strncpy(method, request, i);
	method[i] = '\0';
	
	buf = strstr(request, "//");
	i = 2;
	int defaultPort = 0;
	found = 0;
	while (i < strlen(buf)) {
		if (buf[i] == '/') {
			found = 1;
			defaultPort = 1;
			break;
		}
		else if (buf[i] == ':') {
			found = 1;
			defaultPort = 0;
			break;
		}
		++i;
	}
	if (found != 1) {
		return 0;
	}
	strncpy(hostname, &buf[2], i - 2);
	hostname[i - 2] = '\0';

	if (defaultPort == 1) {
		strcpy(port, "80");
		buf = &buf[i];
	}
	else {
		found = 0;
		buf = strchr(buf, ':');
		i = 1;
		while (i < strlen(buf)) {
			if (buf[i] == '/') {
				found = 1;
				break;
			}
			++i;
		}
		if (found != 1) {
			return 0;
		}
		strncpy(port, &buf[1], i - 1);
		port[i - 1] = '\0';
		buf = &buf[i];
	}

	found = 0;
	i = 0;
	while (i < strlen(buf)) {
		if (buf[i] == ' ') {
			found = 1;
			break;
		}
		++i;
	}
	strncpy(path, &buf[0], i);
	path[i] = '\0';

	buf = strstr(request, "\r\n");
	strcpy (headers, &buf[2]);

	return 1;
}

void test_parser() {
	int i;
	char method[16], hostname[64], port[8], path[64], headers[1024];

       	char *reqs[] = {
		"GET http://www.example.com/index.html HTTP/1.0\r\n"
		"Host: www.example.com\r\n"
		"User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:68.0) Gecko/20100101 Firefox/68.0\r\n"
		"Accept-Language: en-US,en;q=0.5\r\n\r\n",

		"GET http://www.example.com:8080/index.html?foo=1&bar=2 HTTP/1.0\r\n"
		"Host: www.example.com:8080\r\n"
		"User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:68.0) Gecko/20100101 Firefox/68.0\r\n"
		"Accept-Language: en-US,en;q=0.5\r\n\r\n",

		"GET http://localhost:1234/home.html HTTP/1.0\r\n"
		"Host: localhost:1234\r\n"
		"User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:68.0) Gecko/20100101 Firefox/68.0\r\n"
		"Accept-Language: en-US,en;q=0.5\r\n\r\n",

		"GET http://www.example.com:8080/index.html HTTP/1.0\r\n",

		NULL
	};
	
	for (i = 0; reqs[i] != NULL; i++) {
		printf("Testing %s\n", reqs[i]);
		if (parse_request(reqs[i], method, hostname, port, path, headers)) {
			char newReq[MAX_CACHE_SIZE];
			if (strcmp(port, "80")) {
				sprintf(newReq, "%s %s HTTP/1.0\r\nHost: %s:%s\r\nUser-Agent: %s\r\nConnection: close\r\nProxy-Connection: close\r\n\r\n", 
				method, path, hostname, port, user_agent_hdr);
			}
			else {
				sprintf(newReq, "%s %s HTTP/1.0\r\nHost: %s\r\nUser-Agent: %s\r\nConnection: close\r\nProxy-Connection: close\r\n\r\n", 
				method, path, hostname, user_agent_hdr);
			}
			printf("%s", newReq);
		} else {
			printf("REQUEST INCOMPLETE\n");
		}
	}
}

void print_bytes(unsigned char *bytes, int byteslen) {
	int i, j, byteslen_adjusted;

	if (byteslen % 8) {
		byteslen_adjusted = ((byteslen / 8) + 1) * 8;
	} else {
		byteslen_adjusted = byteslen;
	}
	for (i = 0; i < byteslen_adjusted + 1; i++) {
		if (!(i % 8)) {
			if (i > 0) {
				for (j = i - 8; j < i; j++) {
					if (j >= byteslen_adjusted) {
						printf("  ");
					} else if (j >= byteslen) {
						printf("  ");
					} else if (bytes[j] >= '!' && bytes[j] <= '~') {
						printf(" %c", bytes[j]);
					} else {
						printf(" .");
					}
				}
			}
			if (i < byteslen_adjusted) {
				printf("\n%02X: ", i);
			}
		} else if (!(i % 4)) {
			printf(" ");
		}
		if (i >= byteslen_adjusted) {
			continue;
		} else if (i >= byteslen) {
			printf("   ");
		} else {
			printf("%02X ", bytes[i]);
		}
	}
	printf("\n");
}

int open_sfd(int argc, char* argv[]) {
	int sfd, s;
	struct addrinfo hints;
	struct addrinfo *result, *rp;
	memset(&hints, 0, sizeof(struct addrinfo));

	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = 0;
	hints.ai_flags = 0;

	if(argc < 1) {
		exit(1);
	}

	s = getaddrinfo(NULL, argv[1], &hints, &result);
	if (s != 0) {
		exit(1);
	}

	for (rp = result; rp != NULL; rp = rp->ai_next) {
		sfd = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
		if (sfd == -1) {
			continue;
		}
		break;
	}

	int optval = 1;
	setsockopt(sfd, SOL_SOCKET, SO_REUSEPORT, &optval, sizeof(optval));

	if (fcntl(sfd, F_SETFL, fcntl(sfd, F_GETFL, 0) | O_NONBLOCK) < 0) {
		exit(1);
	}

	if (bind(sfd, result->ai_addr, result->ai_addrlen) < 0) {
		exit(1);
	}

	listen(sfd, 100);

	if (fcntl(sfd, F_SETFL, fcntl(sfd, F_GETFL, 0) | O_NONBLOCK) < 0) {
		exit(1);
	}

	return sfd;
}

void handle_new_clients(int efd, int lfd) {
	while (1) {
		socklen_t clientlen = sizeof(struct sockaddr_storage);
		struct sockaddr_storage clientaddr;
		int nsfd = accept(lfd, (struct sockaddr *)&clientaddr, &clientlen);

		if (nsfd < 0) {
			if (errno != EWOULDBLOCK || errno != EAGAIN) {
				exit(EXIT_FAILURE);
			} else {
				break;
			}			
		}

		if (fcntl(nsfd, F_SETFL, fcntl(nsfd, F_GETFL, 0) | O_NONBLOCK) < 0) {
			exit(1);
		}

		newRequest = (struct request_info *)malloc(sizeof(struct request_info));
		newRequest->clientfd = nsfd;

		event.data.ptr = newRequest;
		event.events = EPOLLIN | EPOLLET;
		if (epoll_ctl(efd, EPOLL_CTL_ADD, nsfd, &event) < 0) {
			exit(1);
		}
	}
}

void handle_client(struct request_info *request, int erfd, int ewfd){
	if (request->state == 0) {
		read_request(request, ewfd);
	}
	if (request->state == 1) {
		send_request(request, erfd);
	}
	if (request->state == 2) {
		read_response(request, ewfd);
	}
	if (request->state == 3) {
		send_response(request);
	}
}


void read_request(struct request_info *request, int ewfd) {
	while(1) {
		int n = recv(request->clientfd, &request->readBuf[request->readFromClient], 2048, 0);

		if (n < 0) {
			if (errno != EWOULDBLOCK || errno != EAGAIN) {
				close(request->clientfd);
				free(request);
			}
			return;
		} 

		request->readFromClient = request->readFromClient + n;
		if (all_headers_received(request->readBuf)) {
			break;
		} 
	}

	char method[16], hostname[64], port[8], path[64], headers[1024];
	if (parse_request(request->readBuf, method, hostname, port, path, headers)) {
		if (strcmp(port, "80")) {
			sprintf(request->writeBuf, "%s %s HTTP/1.0\r\nHost: %s:%s\r\nUser-Agent: %s\r\nConnection: close\r\nProxy-Connection: close\r\n\r\n", 
			method, path, hostname, port, user_agent_hdr);
		}
		else {
			sprintf(request->writeBuf, "%s %s HTTP/1.0\r\nHost: %s\r\nUser-Agent: %s\r\nConnection: close\r\nProxy-Connection: close\r\n\r\n", 
			method, path, hostname, user_agent_hdr);
		}
		request->writeToServer = strlen(request->writeBuf);
		printf("%s", request->writeBuf);
	} else {
		close(request->clientfd);
		free(request);
		return;
	}



	int nsfd, s;
	struct addrinfo hints;
	struct addrinfo *result, *rp;
	memset(&hints, 0, sizeof(struct addrinfo));

	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = 0;
	hints.ai_flags = 0;

	s = getaddrinfo(hostname, port, &hints, &result);
	if (s != 0) {
		close(request->clientfd);
		free(request);
		return;
	}

	for (rp = result; rp != NULL; rp = rp->ai_next) {
		nsfd = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
		if (nsfd == -1)
			continue;

		if (connect(nsfd, rp->ai_addr, rp->ai_addrlen) != -1)
			break;

		close(nsfd);
	}

	if (fcntl(nsfd, F_SETFL, fcntl(nsfd, F_GETFL, 0) | O_NONBLOCK) < 0) {
		close(request->clientfd);
		free(request);
		return;
	}

	request->serverfd=nsfd;
	event.data.ptr = request;
	event.events = EPOLLOUT | EPOLLET;
	if (epoll_ctl(ewfd, EPOLL_CTL_ADD, nsfd, &event) < 0) {
		close(request->clientfd);
		close(request->serverfd);
		free(request);
		return;
	}

	memset(request->readBuf, '\0', request->readFromClient);
	request->state += 1;
}

void send_request(struct request_info *request, int erfd) {
	while(1) {
		int n = write(request->serverfd, &request->writeBuf[request->writtenToServer], request->writeToServer);

		if (n < 0) {
			if (errno != EWOULDBLOCK || errno != EAGAIN) {
				close(request->clientfd);
				close(request->serverfd);
				free(request);
			}
			return;
		}

		request->writtenToServer += n;
		if (request->writtenToServer >= request->writeToServer) {
			break;
		} 
	}

	event.data.ptr = request;
	event.events = EPOLLIN | EPOLLET;
	if (epoll_ctl(erfd, EPOLL_CTL_ADD, request->serverfd, &event) < 0) {
		exit(1);
	}

	memset(request->writeBuf, '\0', request->writtenToServer);
	request->state += 1;
}

void read_response(struct request_info *request, int ewfd) {
	while(1) {
		int n = recv(request->serverfd, &request->readBuf[request->readFromServer], 2048, 0);

		if (n < 0) {
			if (errno != EWOULDBLOCK || errno != EAGAIN) {
				close(request->clientfd);
				free(request);
			}
			return;
		} 

		if (n == 0) {

			break;
		}

		request->readFromServer += n;
	}

	event.data.ptr = request;
	event.events = EPOLLOUT | EPOLLET;
	if (epoll_ctl(ewfd, EPOLL_CTL_ADD, request->clientfd, &event) < 0) {
		exit(1);
	}

	request->writeToServer = request->readFromServer;
	request->state += 1;
}

void send_response(struct request_info *request) {
	while(1) {
		int n = write(request->clientfd, &request->readBuf[request->writtenToClient], request->writeToServer);

		if (n < 0) {
			if (errno != EWOULDBLOCK || errno != EAGAIN) {
				close(request->clientfd);
				close(request->serverfd);
				free(request);
			}
			return;
		}

		request->writtenToClient += n;
		if (request->writtenToClient >= request->writeToServer) {
			break;
		} 
	}

	close(request->clientfd);
	close(request->serverfd);
	request->state += 1;
}
